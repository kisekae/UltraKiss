This set demonstrates audio file behaviour for various types of sound files and audio commands.

UltraKiss supports WAV, AU, AIFF, RMF, MIDI and MP3 audio formats.  UltraKiss also implements a generalized 
mediaplayer() action command for sequential playback of media playlists and video files.

The Java Media Framework product extension is mandatory for all mediaplayer() commands and to play MP3 files 
and other audio files with extended file encodings.  Some WAV formatted files require Java Media Framework. 

MIDI and RMF sequencer files require a soundbank definition file in the Java run time system.  UltraKiss 
includes the required soundbank.gm file on a full bundled program installation.  If MIDI does not play or 
sounds distorted, ensure that a soundbank definition file exists in your jre/lib/audio directory. 

FKiSS sound() and music() action commands will play audio files in all supported formats.  The sound(), 
music(), and mediaplayer() commands all have optional parameters to enable the specification of a repeat 
count for audio playback.

The repeat settings in this set specify repeat options for the next test sequence and do not alter repeat 
counts for currently active sounds.  

Page 0 exercises the sound() command.  Different sounds can be played concurrently.  
Page 1 exercises the music() command.  Different sounds can be played concurrently.  
Page 2 exercises the mediaplayer() command.  Only one sound can be played at a time.  
Page 3 exercises combined sound(), music, and mediaplayer() commands.  

Use this test set to verify audio behaviour with various specifications.

All background pictures are digital photographs of the Canadian Rocky Mountains.  These pictures were taken 
in Roger's Pass, July 2002, while travelling in an automobile at 100 km/hr.  

Audio files are copyright Sun Microsystems and others.

For further information send mail to:  support@kisekaeworld.com
� 2002 WSM Information Systems Inc.